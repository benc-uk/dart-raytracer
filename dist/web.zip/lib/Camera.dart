part of lib_ray;

class Camera
{
  Point3D intersection;
  Vector3D normal;
  Ray reflected_ray;
}